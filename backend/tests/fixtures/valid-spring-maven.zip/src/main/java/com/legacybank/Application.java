package com.legacybank;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class Application {}