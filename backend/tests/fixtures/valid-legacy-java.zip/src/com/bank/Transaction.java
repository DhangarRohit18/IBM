package com.bank;
public class Transaction { private double amount; }