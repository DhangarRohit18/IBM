package com.bank;
public class Account { private String id; }